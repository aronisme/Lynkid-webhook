// Content script for injecting "Use Keyword" buttons on Microstock Momentum Planner (Localhost)
(function () {
    'use strict';

    console.log('Gemini Extension: App Injector loaded');

    // CSS for the inject button
    const style = document.createElement('style');
    style.textContent = `
        .gemini-app-btn {
            padding: 6px;
            border-radius: 8px;
            color: #6366f1; /* Indigo-500 */
            background-color: transparent;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .gemini-app-btn:hover {
            background-color: #e0e7ff; /* Indigo-100 */
            color: #4338ca; /* Indigo-700 */
            transform: scale(1.1);
        }

        .gemini-app-btn:active {
            transform: scale(0.95);
        }

        .gemini-app-btn svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
            stroke-width: 2.5;
            fill: none;
            stroke-linecap: round;
            stroke-linejoin: round;
        }
        
        .gemini-app-btn-anim {
            animation: gemini-pulse 0.5s ease-in-out;
        }

        @keyframes gemini-pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
    `;
    document.head.appendChild(style);

    // Function to inject buttons
    function injectButtons() {
        // 1. Target MAIN LIST items (li.group/item)
        const mainListItems = document.querySelectorAll('li.group\\/item');
        mainListItems.forEach(li => {
            if (li.querySelector('.gemini-app-btn')) return;
            const textSpan = li.querySelector('span.truncate');
            if (!textSpan) return;
            const keyword = textSpan.textContent.trim();
            const btnContainer = li.querySelector('.flex.items-center.gap-1');
            if (!btnContainer) return;

            const btn = createBtn(keyword);
            btnContainer.insertBefore(btn, btnContainer.firstChild);
        });

        // 2. Target MODAL items (Visual Angles & Keywords)
        // Identifying class: group flex items-center justify-between px-6 py-4
        // We look for the span with the text
        const modalItems = document.querySelectorAll('.divide-y.divide-slate-100 > div.group');

        modalItems.forEach(div => {
            if (div.querySelector('.gemini-app-btn')) return;

            // Text is in the span
            const textSpan = div.querySelector('span.text-slate-700');
            if (!textSpan) return;

            const keyword = textSpan.textContent.trim();

            // The copy button is usually the last child
            // We want to insert our button BEFORE the copy button
            const copyBtn = div.querySelector('button[title="Salin"]');

            if (copyBtn) {
                const btn = createBtn(keyword);
                // Add some margin to the right of our button
                btn.style.marginRight = '8px';
                // Insert before the copy button
                div.insertBefore(btn, copyBtn);
            }
        });
    }

    function createBtn(keyword) {
        const button = document.createElement('button');
        button.className = 'gemini-app-btn';
        button.title = `Generate Prompt dari: ${keyword}`;
        button.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
        `;

        button.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation(); // Stop it from triggering the row click
            console.log('Sending keyword to extension:', keyword);

            chrome.runtime.sendMessage({
                action: 'useKeywordFromTrends',
                keyword: keyword
            }, (response) => {
                if (chrome.runtime.lastError) {
                    // console.error('Error sending message:', chrome.runtime.lastError);
                    // alert('Gagal mengirim ke ekstensi. Pastikan Side Panel terbuka!');
                } else {
                    button.classList.add('gemini-app-btn-anim');
                    button.style.color = '#10b981';
                    setTimeout(() => {
                        button.classList.remove('gemini-app-btn-anim');
                        button.style.color = '#6366f1';
                    }, 1000);
                }
            });
        });
        return button;
    }

    // Initial injection
    injectButtons();

    // Re-inject on DOM changes (React updates)
    const observer = new MutationObserver((mutations) => {
        let shouldInject = false;
        mutations.forEach(mutation => {
            if (mutation.addedNodes.length > 0) {
                shouldInject = true;
            }
        });
        if (shouldInject) {
            // Debounce slightly
            setTimeout(injectButtons, 200);
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

})();
